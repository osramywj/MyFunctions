from bs4 import BeautifulSoup
import re
class HtmlParser(object):

    def parse(self,url,html):
        if url==None or html==None:
            return
        soup = BeautifulSoup(
            html,
            'html.parser',
            # from_encoding = 'utf-8'
        )

        title_node = soup.find('dd',class_='lemmaWgt-lemmaTitle-title').find('h1')
        title_text = title_node.get_text()

        summary_node = soup.find('div',class_='lemma-summary')
        summary_text = summary_node.get_text()



        links = soup.find_all('a',href=re.compile(r'/item/.*'))
        # return links
        new_urls=set()
        for link in links:
            new_url = 'https://baike.baidu.com'+link['href']
            new_urls.add(new_url)

        new_data = {'url':url,'title':title_text,'summary':summary_text}

        return new_urls,new_data

