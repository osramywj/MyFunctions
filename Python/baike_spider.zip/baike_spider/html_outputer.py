class HtmlOutputer(object):
    def __init__(self):
        self.datas=[]
    def collect(self, new_data):
        if new_data is None:
            return
        self.datas.append(new_data)

    def show(self):
        html = open('echo.html','w')
        html.write('<html>')
        html.write('<body>')
        html.write('<table border="1px">')
        for data in self.datas:
            html.write('<tr>')
            html.write('<td>%s</td>' % data['url'])
            html.write('<td>%s</td>' % data['title'])
            html.write('<td>%s</td>' % data['summary'])
            html.write('</tr>')
        html.write('</table>')
        html.write('</body>')
        html.write('</html>')
        html.close()