# from baike_spider import url_manager, html_downloader, html_parser, html_outputer
from osram.baike_spider import url_manager, html_downloader, html_parser, html_outputer


class SpiderMain(object):
    def __init__(self):
        self.urls = url_manager.UrlManager()
        self.downloader = html_downloader.HtmlDownloader()
        self.parser = html_parser.HtmlParser()
        self.outputer = html_outputer.HtmlOutputer()
    def craw(self, url):
        self.urls.add_new_url(url)

        count=0
        while self.urls.has_new_url():
            # try:
                new_url = self.urls.get_new_url()

                new_html = self.downloader.download(new_url)

                new_urls, new_data = self.parser.parse(new_url,new_html)
                # print(new_urls)
                # quit()
                self.urls.add_new_urls(new_urls)
                self.outputer.collect(new_data)
                print('craw: %d %s' % (count, new_url))
                if count > 10:
                    break
                count = count + 1
            # except Exception:
            #     print('failed')
        self.outputer.show()
        print(self.urls.url_count())#打印url管理还有多少没输出


if __name__=='__main__':
    root_url = 'https://baike.baidu.com/item/Python/407313?fr=aladdin'
    obj_spider = SpiderMain()
    obj_spider.craw(root_url)