from urllib import request
import ssl
ssl._create_default_https_context = ssl._create_unverified_context

class HtmlDownloader(object):
    def download(self, url):
        if url==None:
            return None
        res = request.urlopen(url)
        if res.status!=200:
            return None
        return res.read().decode('utf-8')
