<?php

    header("Content-Type: text/html; charset=utf-8");

    $files = $_FILES['attachInput'];
    echo "上传Succuss：";
    print_r($files);

