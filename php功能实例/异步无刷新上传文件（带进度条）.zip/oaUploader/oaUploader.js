/**
 * oa上传类
 * 2016-05-01 By Reson.dai
 * http://www.daixiaorui.com
 */

var oaUploader = {

	objBtnId : "", //绑定到ID
	postUrl : "", //post上传地址
	formId : "attachForm", //表单id
	inputName : "attachInput", //$_POST['attachInput']
	inputId : "attachInput", //
	barWidth : 200, //进度条默认宽度为200px
	isMutiple : true, //默认支持多文件批量上传

	/**
	 * 初始化参数
	 */
	initParam : function(params){
		this.objBtnId = params.objBtnId || alert("no objBtnId");
		this.postUrl = params.postUrl ||  alert("no postUrl");
		this.formId = params.formId ||  this.formId;
		this.inputName = params.formId ||  this.inputName;
		this.inputId = params.formId ||  this.inputId;
		this.barWidth = params.formId ||  this.barWidth;
		this.isMutiple = params.isMutiple==undefined ? this.isMutiple : params.isMutiple;
	},

	/**
	 * 上传文件
	 */
	upload : function(params){

		this.initParam(params); //初始化参数

		$("#"+this.objBtnId).append(this.bulidForm()); //将上传html绑定到指定的容器中

		var fm = document.getElementById(this.formId); //获取表单对象
		//开始上传文件
		$("#"+this.inputId).change(function(){
			var fd = new FormData(fm);
			var xhr = new XMLHttpRequest();
			oaUploader.barInit();
			xhr.upload.onprogress = oaUploader.process; //进度条
			// console.log(xhr);
			xhr.onreadystatechange = function(){
				if(xhr.readyState == 4){
					oaUploader.endUpload(xhr); //上传完成
				}
			}
			xhr.open('post', oaUploader.postUrl);
			xhr.send(fd);
		
		});
	},

	/**
	 * 上传完成后的处理
	 */
	endUpload : function(xhr){
		if(xhr.status == 200){
			console.log(xhr.responseText);
		}else{
			console.log("上传失败");
		}
	},

	/**
	 * 创建一个动态表单
	 */
	bulidForm : function(){
		var multiple = this.isMutiple ? 'multiple="multiple"' : '';
		var inputName = this.isMutiple ? this.inputName+'[]' : this.inputName;
		var formHtml = '<form action="'+this.postUrl+'" id="'+this.formId+'"><input type="file" name="'+inputName+'" id="'+this.inputId+'" '+multiple+' size="50"/></form>';
		var uploaderHtml = '<div class="uploaderBtn">'+formHtml+'</div><div class="progressBar"><div class="innerBar"></div><span><span></div>';
		return uploaderHtml;
	},

	/**
	 * 进度条效果
	 */
	process : function(p){
		var loadedSize = p.loaded; //已上传的大小
		var totalSize = p.total; //总大小
		// console.log(loadedSize+"/"+totalSize);
		var innerBarWidth = (loadedSize / totalSize * 100) + "%";
		$(".innerBar").css("width",innerBarWidth);
	},

	/**
	 * 进度条初始化
	 */
	barInit : function(){
		$(".progressBar").css({"display":"block","width":this.barWidth+"px"});
	}

};
